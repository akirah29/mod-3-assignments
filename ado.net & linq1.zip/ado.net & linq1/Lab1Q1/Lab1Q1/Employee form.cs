﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Lab1Q1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection(@"data source=NDAMSSQL\SQLilearn;initial catalog=Training_20Feb_Mumbai;user id=sqluser;password=sqluser");
            con.Open();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"data source=NDAMSSQL\sqlilearn;initial catalog=Training_20Feb_Mumbai;user id=sqluser;password=sqluser");
                con.Open();
                SqlDataReader dreader = null;
                //The Procedure to execute
                SqlCommand cmd = new SqlCommand("GetEmployeeById1_175139", con);
                cmd.CommandType = CommandType.StoredProcedure;

                //define procedure parameter SqlParameter prm;
                SqlParameter prm = new SqlParameter("@eno",SqlDbType.Int);
                // prm.SqlDbType = SqlDbType.Int;
                // prm.Direction = ParameterDirection.Input;
                // prm.ParameterName = "@eno"; 
                cmd.Parameters.Add(prm);

                //assign parameter value 
                cmd.Parameters["@eno"].Value = EmpNo.Text;

                dreader = cmd.ExecuteReader();

                //if employee record found 
                if (dreader.Read())
                {
                    EmpName.Text = dreader["empname"].ToString();
                    Sal.Text = dreader["empsal"].ToString();
                    if (dreader["emptype"].ToString() == "P") PayRoll.Checked = true;
                    else Consult.Checked = true;
                }
                else
                {
                    button2_Click(button2, e);
                    MessageBox.Show("No such employee");
                }
                dreader.Close();
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data source=NDAMSSQL\sqlilearn;initial catalog=Training_20Feb_Mumbai;user id=sqluser;password=sqluser");
                con.Open();
                //The Insert DML to add employee record 
                SqlCommand cmd = new SqlCommand ("insert into Employee22_175139 values(@enm,@esal,@etyp)", con);

                //The Parameters 
                //cmd.Parameters.Add("@eno", SqlDbType.Int);
                cmd.Parameters.Add("@enm", SqlDbType.VarChar, 50);
                cmd.Parameters.Add("@esal", SqlDbType.Decimal);
                cmd.Parameters.Add("@etyp", SqlDbType.VarChar, 1);

                //Assigning Values to parameters
               // cmd.Parameters["@eno"].Value = EmpNo.Text;
                cmd.Parameters["@enm"].Value = EmpName.Text;
                cmd.Parameters["@esal"].Value = Sal.Text;
                cmd.Parameters["@etyp"].Value = PayRoll.Checked == true ? "P" : "C";

                //Execute Insert .... 
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee Details Saved"); 
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            EmpNo.Text = "";
            EmpName.Text = "";
            Sal.Text = "";
            EmpNo.Focus();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data source=NDAMSSQL\sqlilearn;initial catalog=Training_20Feb_Mumbai;user id=sqluser;password=sqluser");
          // con.Open();
            SqlCommand command = new SqlCommand();
            command.Connection = con;
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "GetEmployeeById2_175139 ";
            SqlParameter Param1 = new SqlParameter("@eno", SqlDbType.Int);
            command.Parameters.Add(Param1);
            command.Parameters["@eno"].Value = EmpNo.Text;
            con.Open();
            if(MessageBox.Show("Delete?","Confirm Delete",MessageBoxButtons.OKCancel)==DialogResult.OK)
            {
                command.ExecuteNonQuery();
                MessageBox.Show("Deleted");

            }
            else
            {
                MessageBox.Show("not deleted");
            }
        }
    }
}



