﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Lab4Q1_2
{
    //SqlConnection con;
    //SqlDataAdapter da;
    //DataSet ds;
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void save_Click(object sender, EventArgs e)
        {
            try
            {
                //Save Changes to Database
                da.Update(ds.Tables["cust"]);
                MessageBox.Show("Changes Saved");
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
        }

        private void make_Click(object sender, EventArgs e)
        {
            ds.Tables["cust"].RejectChanges();
        }
        SqlConnection con;
        SqlDataAdapter da;
        DataSet ds;
        private void Form1_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data source=NDAMSSQL\sqlilearn;initial catalog=Training_20Feb_Mumbai;user id=sqluser;password=sqluser");

            con.Open(); ds = new DataSet();
            //select - For Data Retrieval               
            da = new SqlDataAdapter("select * from Supplier1_175139 ", con);

            da.Fill(ds, "cust");
            grdUsers.DataSource = ds.Tables["cust"];

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            ds.Tables["cust"].DefaultView.Sort = comboBox1.Text;

        }
    }
}
