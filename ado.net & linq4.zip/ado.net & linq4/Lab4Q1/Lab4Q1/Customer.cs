﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Lab4Q1
{
    public partial class Customer : Form
    {
        SqlConnection con;
        SqlDataAdapter da;
        DataSet ds;
        public Customer()
        {
            InitializeComponent();
        }

        private void Customer_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data source=NDAMSSQL\sqlilearn;initial catalog=Training_20Feb_Mumbai;user id=sqluser;password=sqluser"); 

            con.Open(); ds = new DataSet();
            //select - For Data Retrieval               
            da = new SqlDataAdapter("select * from customer_175139", con); 

            da.Fill(ds, "cust");

            grdCustomer.DataSource = ds.Tables["cust"];
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            ds.Tables["cust"].DefaultView.Sort = comboList.Text;

        }

        private void Showbutton_Click(object sender, EventArgs e)
        {
            ds.Tables["cust"].DefaultView.RowFilter = "City like '" +txtCusCity.Text + "'";
            

        }
    }
}
