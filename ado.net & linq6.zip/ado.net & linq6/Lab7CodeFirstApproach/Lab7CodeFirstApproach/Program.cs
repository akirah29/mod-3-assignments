﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab7CodeFirstApproach
{
    class Program
    {
        static void Main(string[] args)
        {
            ProductContext pcontext = new ProductContext();
            Product p1 = new Product()
            {
                ProductId = 101,
                Name = "Barbie Doll",
                Categories = "Toys",
                Price = 199.99M
            };
            Product p2 = new Product()
            {
                ProductId = 102,
                Name = "Montee Pen",
                Categories = "Stationary",
                Price = 10.99M
            };
            pcontext.Product.Add(p1);
            pcontext.Product.Add(p2);
            pcontext.SaveChanges();
            Console.Write("Products Details Added Sucessfully");
            Console.ReadLine();
        }
    }
}


