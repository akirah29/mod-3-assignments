﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatabaseConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            CodeFirstApproachEntities firstapproach = new CodeFirstApproachEntities();
            Album_175139 album = new Album_175139()
            {
                Name = "Rockin",
                Genre = "Rock",
                year= Convert.ToDateTime("2/2/2007"),
                Price = 39,
            };
            firstapproach.Album_175139.Add(album);
            firstapproach.SaveChanges();

            Console.WriteLine("album details added successfully");
            //Console.ReadLine();
            var albums = firstapproach.Album_175139;
            foreach (Album_175139 a in albums)
            {
                Console.WriteLine(a.AlbumId + "\t" + a.Name + "\t" + a.Price);
            }
             Console.ReadLine();
        }
    }
}
