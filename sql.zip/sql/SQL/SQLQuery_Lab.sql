--------Lab
CREATE TABLE Customer
(
	CustomerId int unique not null,
	CustomerName varchar(20) not null,
	Address1 varchar(30) not null,
	Address2 varchar(30) not null,
	ContactNumber varchar(20) not null,
	PostalCode varchar(20)
)

create table Employee
(
	EmployeeID int not null primary key,
	Name nvarchar(255) null
)

create table Contractors
(
	contractorID int not null primary key,
	name nvarchar(255) null
)

create table Testrethrow
(
	id int primary key
);

Create type Region_175139 from varchar(20) not null 

create default defregion_175139 as 'NA'


sp_bindefault defregion_175139, 'Region_175139'

alter table Customer add Customer_region Region_175139
alter table Customer add Gender char(1) 
alter table Customer add check(Gender in('M','F','T'))

--------------7 orders-----------------
create table Orders_175139
(
ordersID int not null identity (1000,1),
customerID int not null,
ordersDate datetime
)
sp_help Orders_175139

----------Task 1----------------------------
create sequence Idsequence_175139 as int
start with 10000
increment by 1
------------Task 2----------------------------
INSERT INTO Employee (EmployeeID, Name)  VALUES (NEXT VALUE FOR Idsequence_175139, 'Shashank'); 
 
INSERT INTO Contractors(contractorID, Name)  VALUES (NEXT VALUE FOR Idsequence_175139, 'Aditya'); 
 
SELECT * FROM Employee; 
 
SELECT * FROM Contractors; 
--------------------------1.4-----------------------
----------------Task 1--------------------------------\

 create table Student_Master_175139
  (
    StudentCode int primary key not null,
	studentname varchar(50) not null,
	Deptcode int,
	Foreign key(Deptcode)References  Department_Master(Deptcode),
	Student_dob datetime,
	Student_Add varchar(240)
	--Deptcode int foreign key(Deptcode)REFERENCEs Department_Master(Deptcode)
	)
	insert into Student_master_175139 values(1,'sulochana',2,'2/2/2016','Hyd')
select * from Student_master_175139
select StudentCode,studentname,Deptcode from Student_master_175139
----------------Task 2-----------------------------------
Create table Staff_Master_175139
	 (
	 Staff_code  int not null,  
   Staff_Name  Varchar(50) not null,  
Design_code int,
foreign key(Design_code)References Desig_Master(Designcode),
Dept_code  int ,
foreign key(Dept_code)References Department_Master(Deptcode),
HireDate  Datetime , 
Staff_dob  Datetime  ,
Staff_address  Varchar(240),  
Mgr_code  int  ,
Staff_sal  decimal (10,2)
)
insert into Staff_Master_175139 values(1,'jhxgshw',1,2,'6/3/2017','6/3/2017','Hyd1',62,2505)


select * from Staff_Master_175139
select Staff_code,staff_Name,Dept_code from Staff_Master_175139
-----------------Task 3-----------------------------------
 select StudentCode,studentname,Deptcode from Student_master_175139
 where Deptcode in (10,20,30)
 --------------------Task 4----------------------------
 
	Create table Student_Marks_175139
	(
	 StudentCode int primary key foreign key (StudentCode)References Student_MasterTable4(StudentCode),
	 Studentyear int not null,
	 Subject1 int,
	 Subject2 int,
	 Subject3 int
	 )

select * from student_marks
select StudentCode,Subject1,Subject2,Subject3,
Subject1+Subject2+Subject3 as totalmarks
from student_marks order by totalmarks desc
-------Task5---------------------------
create table Book_Master
	(
	 Book_Code  int primary key not null ,
     Book_Name  Varchar(50) not null,
    Book_pub_year  int ,
    Book_pub_author  Varchar(50) ,
     Book_category   Varchar(10) 
	 )
	     

Select * from Book_Master where Book_Name Like 'a%'

---------------------Task 8-------------------------------
select * from Staff_Master

 select staff_code,staff_name,dept_code,Hiredate,
 datediff(yyyy,hiredate,getdate()) as numberofyears from staff_master
 -----------------------Task 9-------------------------------
 select * from Staff_Master where hiredate < '2000-01-01'
-----------------------------Task 10-----------------------------
select  * from student_master_175139 where Studentcode BETWEEN '1/1/1981' and '31/3/1983'


-----------------------------------------------------------------1.5-------------------------------------------------------------------
create table Book_Master
	(
	 Book_Code  int primary key not null ,
     Book_Name  Varchar(50) not null,
    Book_pub_year  int ,
    Book_pub_author  Varchar(50) ,
     Book_category   Varchar(10) 
	 )

---1
select Staff_Name,Dept_code,Staff_sal from Staff_Master_175139 where Staff_sal>=2000
---2
select Staff_Name,Dept_code from Staff_Master_175139 where Dept_code!=10

---8
select studentcode,subject1 from student_marks 
where subject1=(select max(subject1) from student_marks)

---9
select b.studentcode,subject1,studentname from student_marks a
 inner join student_master b on a.stud_code=b.stud_code
where subject1=(select max(subject1) from student_marks)

--10
select * from book_master
select * from Book_Transaction

select book_code,author,book_category from book_master
where not exists(select * from book_transaction
where book_master.book_code=book_Transaction.book_code)

--11

select * from staff_master
select * from student_master
 select staff_code,staff_name,stud_code,stud_name,b.dept_code 
 from staff_master a inner join student_master b
 on a.dept_code=b.dept_code 
 where b.dept_code=20
 
--12 
 select * from Student_master
 select * from Student_master

 select b.stud_code,stud_name,a.year from Student_master a
 inner join student_marks b on a.stud_code=b.stud_code
 where a.year<>2018

--13
 select * from Student_master
 select * from book_transaction

 select a.stud_code,a.stud_name,b.book_code 
 from Student_master a right outer join Book_Transaction b
 on a.Stud_Code=b.stud_code

 ----14

select * from Customer
truncate table Customer

insert into Customer
values('ALFKI','AlfredsFutterKiste','ObereStr.57','Berlin Germany',
030-0074321,12209,NULL,NULL)

insert into Customer values
('ANATR','Ana Trujillo',
'Avda.dela constitucion 2222','Mexico DF.Mexico',5554729,5021,
'NA',NULL)

insert into Customer values('ANTON',
'Antonio','matadero 2312','Mexico DF.MEXICO'
,5553932,5023,NULL,NULL)

insert into Customer values('AROUT',
'around the Horn','120 Hanover sq.','London UK',
5557788,'WA1 iDP',NULL,NULL)

insert into Customer values('BERGS',
'Berglundssnabbkop','Berguvsvagen 8','Lulea Sweden'
,0921123465,'S958 22',NULL,NULL)

insert into Customer values('BLAUS',
'Blauer see Delik','Forster 57','Mannheim Germany',062108460,
68306,'NA',NULL)

insert into Customer values('BLONP',
'Blondesddslpreet','24,place kleber','Strausbourg France'
,88.601531,67000,NULL,NULL)

insert into Customer values('BOLID',
'Bolindo paradas','c/ araquil 67','Madrid Spain',5552282,
28023,'EU',NULL)

insert into Customer values('BONAP','Bon app'
,'12,rueders bouchers','Marseille France',91.244540,13008,NULL,NULL)

insert into Customer values('BOTTM',
'Bottom Dollar','23 Tsawessen Blvd','Tsawessen canada',
5554729,'T2F8M4','BC',' ')


--15
update Customer set 
contactNumber=replace(contactnumber,5554729,3332345)
where customerid='ANATR'

--16
update Customer set 
address1=replace(address1,'23 Tsawessen Blvd','19/2 12th blockSpring fields')
update Customer set
address2=replace(address2,'Tsawessen canada','Ireland-UK')
where customerid='BOTTM'
update Customer set
region=replace(region,'BC','EU')
where customerid='BOTTM'

--17

insert into Orders_175139(customerid,ordersdate,orderstate)
values ('AROUT','4-jul-96','P')

insert into Orders_175139(customerid,ordersdate,orderstate)
values ('ALFKI','4-jul-96','C')

insert into Orders_175139(customerid,ordersdate,orderstate)
values ('BLONP','8-jul-96','P')

insert into Orders_175139(customerid,ordersdate,orderstate)
values ('ANTON','8-jul-96','P')

insert into Orders_175139(customerid,ordersdate,orderstate)
values ('ANTON','9-jul-96','P')

insert into Orders_175139(customerid,ordersdate,orderstate)
values ('BOTTM','10-jul-96','P')


insert into Orders_175139(customerid,ordersdate,orderstate)
values ('BONAP','11-jul-96','C')

insert into Orders_175139(customerid,ordersdate,orderstate)
values ('ANATR','12-jul-96','P')

insert into Orders_175139(customerid,ordersdate,orderstate)
values ('BLAUSS','15-jul-96','P')

insert into Orders_175139(customerid,ordersdate,orderstate)
values ('HILAA','16-jul-96','C')


---18
 delete from Orders_175139 where ordersstate='C'
select* from Orders_175139



---19

truncate table Orders_175139

---20
update Orders_175139 set ordersstate='C' where ordersdate<'1996-07-15'



--------(1.6)...1
 alter table Department_master add constraint deptname_UQ unique(dept_name)
 SELECT *from Department_master
 SP_HELP Department_master
select *  from sys.indexes where object_id=object_id('Department_master')

-------------------(1.6)...2
-------------
delete  Department_master where Dept_code=60 or Dept_code=90
insert into Department_master values(61,'home sciences')
insert into Department_master values(71,'home sciencess')
insert into Department_master values(80,NULL)
insert into Department_master values(90,NULL)
-----------------------------------------------------
-------------(1.6)....3
select *from Book_Transaction
select *  from sys.indexes where object_id=object_id('Book_Transaction')
alter table Book_Transaction add constraint book_code_UQ unique(book_code)  
alter table Book_Transaction alter column stud_code    


-------------------------------------
-------------(1.6)....4..
select *  from sys.indexes 
select *  from sys.indexes where object_id=object_id('Department_master')

--------------(1.6)....5
 select *  from [dbo].[Desig_master]
 select *  from [dbo].[Department_master]
 select *  from [dbo].[Staff_Master] 





  create view StaffDetails_view1_175139 as select st.Staff_Code,
  st.Staff_Name, Dept_Name,Design_Name, Salary 
 from dbo.Staff_Master st  inner join dbo.Desig_master de
  on st.Des_code=de.Design_code 
  inner  join dbo.Department_master dm on  
  de.Design_Code=dm.Dept_code
  select *from dbo.Staff_Master
  select *from  dbo.Department_master
  select *from dbo.Desig_master

select Staff_Code, Staff_Name, Dept_Name, Design_Name, Salary from StaffDetails_view1_175139
 insert into StaffDetails_view1_175139 values(10004,'saikiran','ece',10000) 
---------1.6.6-

insert into staff_v2 values(100012,'vadiraj',104,30,'1996-07-11 00:00:00:000','2018-12-12 00:00:00:000',100009,20000.00,'bangalore')
select * from staff_master

----------1.6.7
CREATE NONCLUSTERED INDEX FIBillOfMaterialsWithEndDate
ON Production.BillOfMaterials (ComponentID, StartDate)
WHERE EndDate IS NOT NULL
------1.6.8
sp_helptext staff_v2

-----1.6.9---
create view staff_v2 as
select* from Staff_Master where DATENAME(month,hiredate)='June'
--1.6.10------
CREATE UNIQUE INDEX idx_employees_175139
 ON Employees(Employee_id)
select * from employees
sp_help employees



---1.7------

--1.7   Procedures and Exception Handling in SQL server
--1.    Write a procedure that accept Staff_Code and updates the salary and store the old salary details in Staff_Master_Back (Staff_Master_Back has the same structure without any constraint) table. The procedure should return the updated salary as the return value 
--Exp< 2 then no Update
--Exp>= 2 and <= 5 then 20% of salary 
--Exp> 5 then 25% of salary

select * from staff_master;
select * from staff_master_back;
sp_help staff_master

CREATE PROCEDURE proc_staffslryUpdate_175139
	 @staffcodes varchar(10)
as
declare
@variableone varchar(10),
@experience date,
@experienceyears varchar(5);
Begin
    If @staffcodes is null 
        Begin 
            throw 50008,'Invalid city',12
        end 
    else

    select @variableone=Salary,@experience=hiredate,@experienceyears=datediff(year,hiredate,GETDATE())  from staff_master where Staff_Code=@staffcodes;
    if @variableone is not null
        Begin 
         if @experienceyears>= 2 and @experienceyears<= 5
             begin
                update Staff_Master set salary=salary+((25*(salary))/100) where Staff_Code=@staffcodes;
             end 
         if @experienceyears> 5
            begin
                update Staff_Master set salary=salary+((20*(salary))/100) where Staff_Code=@staffcodes;
            end
         insert into staff_master_back select * from Staff_Master where Staff_Code=@staffcodes;
        end
end


begin try
exec proc_staffslryUpdate_172326 '10001'
end try
begin catch
    print Error_Message()
end catch

--2.Write a procedure to insert details into Book_Transaction table. Procedure should accept the book code
-- and staff/student code. Date of issue is current date and the expected return date should be 10 days from
-- the current date. If the expected return date falls on Saturday or Sunday, then it should be the next working day.
-- Suitable exceptions should be handled.

select * from Book_Transaction;

create Procedure Userdefindproc_booktrans_175139 @bookCode varchar(10),@scode varchar(10)
as
declare
@variableone varchar(10), @variabletwo varchar(10),@variablethree varchar(10),@datevar varchar(10)
begin
if @bookCode is null and @scode is null
    begin
        throw 50008,'enterred book and code invalid',12
    end
else
   select @variableone=book_name from Book_Master where Book_code=@bookcode;
   select @variabletwo=stud_code from Student_master where Stud_Code=@scode;
   select @variablethree=staff_code from Staff_Master where Staff_Code=@scode;
   if (@variableone is not null and (@variabletwo is not null or @variablethree is not null))
   begin
        select @datevar=datename(weekday,DATEADD(DAY,10,getdate())) 
        
        if @datevar= ('Sunday')
         begin
            insert into Book_Transaction (book_code,Stud_code,Staff_code,Issue_date,Exp_Return_date)
            values(@bookCode,@variabletwo,@variablethree,GETDATE(),DATEADD(DAY,11,getdate()));
         end
        if @datevar='Saturday'
         begin
                insert into Book_Transaction (book_code,Stud_code,Staff_code,Issue_date,Exp_Return_date)
                values(@bookCode,@variabletwo,@variablethree,GETDATE(),DATEADD(DAY,12,getdate()));
         end
        if @datevar not in ('Saturday','Sunday')
         begin
                insert into Book_Transaction (book_code,Stud_code,Staff_code,Issue_date,Exp_Return_date)
                values(@bookCode,@variabletwo,@variablethree,GETDATE(),DATEADD(DAY,10,getdate()));
          end

    end
end

select * from Book_Master;
select * from Student_Marks;
begin try
exec Userdefindproc_booktrans_175139 '10000003','1002'
end try
begin catch 
 print error_message()
end catch








--LAB-2
-----
--1
---
select *from employee
select EmpID,EmpName,Department from employee where DATEDIFF(year,Joiningdate,getdate())>18



select *from staff_master
select *from Book_Master
select *from Book_transaction


--3
----
select book_code from Book_transaction where Actual_Return_Date>=Exp_Return_date

--4
---

select *from staff_master where datename(month,staff_dob)=datename(month,getdate())

--5
------------
select *from staff_master
select *from book_transaction
select count(Book_code) as student_books from book_transaction where Actual_Return_date is not null

--6
---
select book_name,count(book_code)as total_books from book_master where book_name='physics or chemistry'
group by book_name

--7
--
select book_code,stud_code from Book_Transaction where actual_return_date=datepart(day,getdate())

--8
------
select staff_name,round(min(salary),2)as Minimum,round(max(salary),6) as Maximum,round(sum(salary),3) as Total,round(avg(salary),3) as Average from staff_master
group by staff_name

--9
--
select s.staff_name from staff_master s,staff_master m
where (m.Mgr_code=s.staff_code) 

--10
-------
select stud_year,count(stud_code) from student_marks
where (subject1>60 or subject2>60 or subject3>60)
group by stud_year

--11
-----------
select dept_code,count(*) from department_master
group by Dept_Code
having count(dept_code)>10

select count(dept_code) from staff_master
where dept_code in (select dept_code from department_master
group by dept_code
having count(dept_code)>10) 


--12
----------
select sum(price) as total_book_inventary from book_master


--13
---
select count(book_category) as book_category,Price  from book_master
where price>1000
group by price

--14
--------
select count(dept_code) as total from staff_master
where dept_code in (select dept_code from department_master where dept_name= 'home science') 

--2.2
-----------------------------------------------
--1
select * from Staff_Master
select Staff_code,Staff_name,Salary

select case when Salary>=50000 then 'A'
            when Salary>=20000 and Salary<50000 then 'B'
            when Salary>=10000 and Salary<20000 then 'C'
            else 'D'
       end as Grade,Staff_Name,Salary from Staff_Master
--------------------------------------------------
--2
select * from Desig_master
select * from Staff_Master
select * from Department_master
select * from Book_Master
select * from Book_Transaction

select sm.staff_code,sm.Staff_Name,dsm.Design_Name,dpm.Dept_Name,bm.book_code,bm.book_name,bm.author,
5*(datediff(day,bt.Exp_Return_date,bt.Actual_Return_date)) as fine
from Desig_master dsm inner join Staff_Master sm on dsm.Design_Code = sm.Des_Code
inner join Department_master dpm on sm.Dept_Code = dpm.Dept_code 
inner join Book_Transaction bt on sm.Staff_Code=bt.Staff_code
inner join Book_Master bm on bm.Book_code=bt.Book_code 

---------------------------------------------------
--3
select * from Staff_Master 

select * from Staff_Master
where Mgr_code in( select Staff_Code from Staff_Master where Staff_Code = 100006) 
--------------------------------------------------
--4
select * from Student_master
select * from Department_master
select * from Desig_master
select * from Staff_Master 
select * from Book_Master
select * from Book_Transaction                                           

select stum.Stud_Name,dpm.Dept_Name
from Student_master stum inner join Department_master dpm on stum.Dept_Code = dpm.Dept_code
inner join Staff_Master stam on stam.Dept_Code = dpm.Dept_code
inner join Desig_master dsm on dsm.Design_Code =stam.Des_Code
inner join Book_Transaction bt on bt.Staff_code=stam.Staff_Code
where bt.Book_code in (select stam.staff_Code from Staff_Master
where dsm.Design_Code in(select dsm.Design_Name from Desig_master
where dsm.Design_Name='Professor'))
------------------------------------------------------
--5
select * from Book_Master
select Author,book_category from Book_Master 
where book_category='Comp Sc' 
-------------------------------------------
--6


select * from Student_master
select * from Department_master

 select  Stud_Code, subject1, subject2, subject3, 
  subject1+subject2+subject3 as totalmarks      
  from Student_Marks order by totalmarks desc 
  

  -- 2.3
-- Create a Filtered Index HumanResources.Employee table present in the AdventureWorks database for the column EmployeeID.
-- The Index should cover all the queries that uses EmployeeID for its search & that select only rows with 'Marketing Manager'
-- for Title Column



create table Countries_175139(country_code int, country_name varchar(10));

sp_help 'Countries_175139'

create index countries_nm 
on Countries_172326(country_name) 
where country_name='India';

select a.name,b.name 
as objectname, a.is_unique, a.type_desc, a.filter_definitiona
from sys.indexes a inner join sys.objects b 
on (a.object_id = b.object_id)
where b.name ='countries'








